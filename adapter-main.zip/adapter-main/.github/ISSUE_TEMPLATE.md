# Please read first!
Please use [discuss-webrtc](https://groups.google.com/forum/#!forum/discuss-webrtc) for general technical discussions and questions.

- [ ] I have provided steps to reproduce (e.g. a link to a [jsfiddle](https://jsfiddle.net/))
- [ ] I have provided browser name, version and adapter.js version
- [ ] This issue only happens when adapter.js is used

**Note: If the checkboxes above are not checked (which you do after the issue is posted), the issue will be closed.**

## Versions affected

**Browser name including version (e.g. Chrome 64.0.3282.119)**


**adapter.js (e.g. 6.1.0)**


## Description


## Steps to reproduce


## Expected results


## Actual results
